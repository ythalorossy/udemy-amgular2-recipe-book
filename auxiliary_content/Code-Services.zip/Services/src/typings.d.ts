/// <reference path="../typings/browser.d.ts" />
declare var module: { id: string };
