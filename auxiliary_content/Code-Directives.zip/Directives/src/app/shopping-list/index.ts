export { ShoppingListComponent } from './shopping-list.component';
