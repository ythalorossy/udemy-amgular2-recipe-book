import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'rb-header',
  templateUrl: 'header.component.html'
})
export class HeaderComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
