import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'recipe-book-app',
  templateUrl: 'recipe-book.component.html'
})
export class RecipeBookAppComponent {
}
